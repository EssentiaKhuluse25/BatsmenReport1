/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.batsmenreport;

/**
 * ST10447535 PROG6112 TEST
 * @author lab_services_student
 */

import java.util.Scanner;

public class BatsmenReport {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Declare arrays
        String[] stadiums = {"Kingsmead", "St Georges", "Wanderers"};
        String[] batsmen = {"Jacques Kallis", "Hashim Amla", "AB De Villiers"};
        int[][] runs = new int[3][3]; // 3 stadiums, 3 batsmen
        int[] stadiumTotals = new int[3]; // Total runs for each stadium
        
        // Input data for each stadium
        for (int i = 0; i < stadiums.length; i++) {
            System.out.println("\nEntering data for " + stadiums[i] + ":");
            
            System.out.print("Enter the number of runs by Jacques Kallis: ");
            runs[i][0] = scanner.nextInt();
            
            System.out.print("Enter the number of runs by Hashim Amla: ");
            runs[i][1] = scanner.nextInt();
            
            System.out.print("Enter the number of runs by AB De Villiers: ");
            runs[i][2] = scanner.nextInt();
            
            // Calculate total for each stadium
            stadiumTotals[i] = runs[i][0] + runs[i][1] + runs[i][2];
        }
        
        // Display the main report
        System.out.println("\n---");
        System.out.println("BATSMEN REPORT");
        System.out.println("---");
        System.out.printf("%-15s %15s %15s %15s\n", "STADIUM", "JACQUES KALLIS", "HASHIM AMLA", "AB DE VILLIERS");
        
        for (int i = 0; i < stadiums.length; i++) {
            System.out.printf("%-15s %15d %15d %15d\n", stadiums[i], runs[i][0], runs[i][1], runs[i][2]);
        }
        
        // Display stadium totals
        System.out.println("\n---");
        System.out.println("RUN TOTALS FOR EACH STADIUM");
        System.out.println("---");
        
        for (int i = 0; i < stadiums.length; i++) {
            System.out.printf("%-15s %10d\n", stadiums[i], stadiumTotals[i]);
        }
        
        // Find stadium with most runs
        int maxRuns = stadiumTotals[0];
        String stadiumWithMostRuns = stadiums[0];
        
        for (int i = 1; i < stadiums.length; i++) {
            if (stadiumTotals[i] > maxRuns) {
                maxRuns = stadiumTotals[i];
                stadiumWithMostRuns = stadiums[i];
            }
        }
        
        System.out.println("\n---");
        System.out.println("STADIUM WITH THE MOST RUNS SCORED BY BATSMEN: " + stadiumWithMostRuns);
        System.out.println("---");
        
        scanner.close();
    }
}
